<?php
//Namespace der Klasse
namespace System;

class Page
{
	private $title = '';
	private $author = HTML_AUTHOR;
	private $description = '';
	private $keywords = '';
	private $breadcrumb = '';
	private $DB;

	/**
	 * Konstruktor der Klasse
	 */
	public function __construct($title = '', $description = '', $keywords = '') {
		$this->title = $title;
		$this->description = $description;
		$this->keywords = $keywords;
		
		$this->DB = $GLOBALS['DB'];
	}
	
	/**
	 * Generiert eine neue Seite.
	 * 
	 * @param unknown $reference
	 * @param $content Funktion die aufgerufen werden soll, um Inhalt darzustellen
	 * @param $newClass Wird eine weitere Klasse benoetigt? z.B. System\Form
	 * @param $params Werden bei $content Parameter uebergeben?
	 */
	public function buildPage($reference, $content = 'printContent', $newClass = null, $params = false) {
		$html = new HTML($reference);
		if ($params == true) {
			$brackets = '';
			$tmp = "$content";
		} else {
			$brackets = '()';
			$tmp = "$content()";
		}
		if ($newClass != null) {
			$class = new $newClass();
		} else {
			$class = null;
		}
		var_dump($newClass);
// 		$REGISTRATION_FORM->printRegistrationForm(PROJECT_HTTP_ROOT.'/content/register/checkRegistrationForm.php');
		
// 		$tmp = $content.$brackets;
		
		$html->printHead($this->title, $this->description, $this->keywords);
		$html->printBody('', false);
		$html->printHeader();
		if ($class != null) {
			$class->$tmp;
			
		} else {
			$html->$tmp;
		}
		$html->printFoot();
	}
	
	public function setBreadcrumb($path) {
		$this->breadcrumb = $path;
	}
	
	public function setAuthor($author) {
		$this->author = $author;
	}
	
	public function getTitle() {
		return $this->title;
	}
	
	public function getAuthor() {
		return $this->author;
	}
	
	public function getDescription() {
		return $this->description;
	}
	
	public function getKeywords() {
		return $this->keywords;
	}
	
	public function getBreadcrumb() {
		$utile = new Utile();
		return $utile->generateBreadcrumb($this->breadcrumb);
	}

}