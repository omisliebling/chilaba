// Bootstrap Carousel
$(document).ready(function() {
	$('.carousel').carousel({
		interval : 5000
	});
});


//$(document).ready(function() {
//	$("#myModal").modal({
//		remote:true
//	});    
//});


