<?php

require_once "../../common.php";

System\HTML::printHead(NAV_STYLEGUIDE);

System\HTML::printBody('', false);
System\HTML::printHeader();

System\HTML::printStyleguide();

System\HTML::printFoot();

?>