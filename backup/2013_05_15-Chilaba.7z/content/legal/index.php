<?php

require_once "../../common.php";

System\HTML::printHead(NAV_LEGAL);

System\HTML::printBody('', false);
System\HTML::printHeader();

System\HTML::printLegalForm();

System\HTML::printFoot();

?>