<?php
require_once "../../common.php";

System\HTML::printHead(NAV_REGISTER);

System\HTML::printBody('', false);
System\HTML::printHeader();

$REGISTRATION_FORM = new System\Form();
$REGISTRATION_FORM->printRegistrationForm(PROJECT_HTTP_ROOT.'/content/register/checkRegistrationForm.php');

//Ende der Seite
System\HTML::printFoot();
?>