<?php
//Namespace der Klasse
namespace System;

class Page
{
	private $title = '';
	private $author = HTML_AUTHOR;
	private $description = '';
	private $keywords = '';
	private $breadcrumb = '';
	private $DB;

	/**
	 * Konstruktor der Klasse
	 */
	public function __construct($title = '', $description = '', $keywords = '') {
		$this->title = $title;
		$this->description = $description;
		$this->keywords = $keywords;
		
		$this->DB = $GLOBALS['DB'];
	}
	
	public function buildPage($reference, $content = 'printContent') {
		$html = new HTML($reference);
		
		$html->printHead($this->title, $this->description, $this->keywords);
		$html->printBody('', false);
		$html->printHeader();
		$html->$content();
		$html->printFoot();
	}
	
	public function setBreadcrumb($path) {
		$this->breadcrumb = $path;
	}
	
	public function setAuthor($author) {
		$this->author = $author;
	}
	
	public function getTitle() {
		return $this->title;
	}
	
	public function getAuthor() {
		return $this->author;
	}
	
	public function getDescription() {
		return $this->description;
	}
	
	public function getKeywords() {
		return $this->keywords;
	}
	
	public function getBreadcrumb() {
		$utile = new Utile();
		return $utile->generateBreadcrumb($this->breadcrumb);
	}

}